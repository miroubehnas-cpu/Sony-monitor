package com.amir.sonymonitor

import android.app.Activity
import android.app.PendingIntent
import android.content.*
import android.hardware.usb.*
import android.net.wifi.WifiManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color

/**
 * Sony Monitor Pro - starter prototype.
 * USB mode detects USB capture devices and requests permission.
 * Actual UVC video decoding/rendering is intentionally not claimed in this prototype.
 * Wi-Fi mode provides setup guidance; Sony's proprietary live-view stream protocol
 * must be implemented/validated against the RX10 IV before it can show video.
 */
class MainActivity : Activity() {
    private lateinit var usbManager: UsbManager
    private lateinit var status: TextView
    private lateinit var details: TextView
    private lateinit var list: LinearLayout
    private val actionUsbPermission = "com.amir.sonymonitor.USB_PERMISSION"
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == actionUsbPermission) {
                val device = intent.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
                val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                status.text = if (granted) "تم منح إذن USB" else "لم يتم منح إذن USB"
                details.text = device?.let { describe(it) } ?: "لم يتم تحديد الجهاز"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(USB_SERVICE) as UsbManager
        registerReceiver(receiver, IntentFilter(actionUsbPermission))
        buildUi()
    }

    private fun buildUi() {
        val base = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 20, 28, 20)
            setBackgroundColor(Color.rgb(8, 10, 13))
        }
        val title = TextView(this).apply {
            text = "SONY MONITOR PRO"
            textSize = 25f
            setTextColor(Color.rgb(226, 184, 94))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "RX10 IV  •  ANDROID MONITOR"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "اختر طريقة الاتصال"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(8, 18, 8, 18)
        }
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        buttons.addView(makeButton("HDMI / USB-C") { scanUsb() }, LinearLayout.LayoutParams(0, 58, 1f).apply { setMargins(5,5,5,5) })
        buttons.addView(makeButton("Wi-Fi") { showWifiGuide() }, LinearLayout.LayoutParams(0, 58, 1f).apply { setMargins(5,5,5,5) })
        details = TextView(this).apply {
            text = "HDMI: صِل Micro-HDMI من الكاميرا إلى بطاقة التقاط UVC، ثم صِل البطاقة بالهاتف عبر OTG.\n\nWi-Fi: اتصل بشبكة الكاميرا واستخدم وضع التحكم اللاسلكي."
            textSize = 15f
            setTextColor(Color.LTGRAY)
            setPadding(8, 18, 8, 18)
        }
        val scan = makeButton("فحص أجهزة USB") { scanUsb() }
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        base.addView(title)
        base.addView(subtitle)
        base.addView(status)
        base.addView(buttons)
        base.addView(details)
        base.addView(scan)
        base.addView(list)
        setContentView(base)
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(45, 49, 56))
        setOnClickListener { action() }
    }

    private fun scanUsb() {
        list.removeAllViews()
        val devices = usbManager.deviceList.values.toList()
        status.text = "أجهزة USB المكتشفة: ${devices.size}"
        if (devices.isEmpty()) {
            details.text = "لم يتم العثور على جهاز. تأكد من تفعيل OTG واستخدام بطاقة التقاط HDMI متوافقة مع UVC وكابل بيانات."
            return
        }
        devices.forEach { device ->
            val row = makeButton(describe(device)) {
                val intent = PendingIntent.getBroadcast(
                    this, device.deviceId, Intent(actionUsbPermission),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
                )
                usbManager.requestPermission(device, intent)
                status.text = "طلب إذن USB..."
            }
            list.addView(row)
        }
        details.text = "اضغط على بطاقة الالتقاط لطلب الإذن. هذه النسخة الأولية تفحص USB فقط؛ عرض الفيديو يحتاج دمج محرك UVC واختباره على هاتف فعلي."
    }

    private fun describe(d: UsbDevice): String =
        "USB ${d.deviceName}\nVID: ${d.vendorId}  PID: ${d.productId}  Interfaces: ${d.interfaceCount}"

    private fun showWifiGuide() {
        status.text = "وضع Wi-Fi"
        details.text = "1) فعّل التحكم عن بُعد عبر الهاتف في RX10 IV.\n2) اتصل من Android بشبكة Wi-Fi التي تنشئها الكاميرا.\n3) افتح Sony Imaging Edge Mobile للتحقق من Live View والتحكم.\n\nملاحظة: بث Live View الخاص بسوني ليس واجهة Android عامة موثقة بالكامل؛ يلزم اختبار بروتوكول RX10 IV قبل تضمينه مباشرة في هذا التطبيق."
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        super.onDestroy()
    }
}
