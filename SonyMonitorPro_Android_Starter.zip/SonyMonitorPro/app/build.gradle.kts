plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.amir.sonymonitor"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.amir.sonymonitor"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-prototype"
    }
}
